
import { createContext, useState, useEffect } from "react";

export const BugContext = createContext();

export const BugProvider = ({ children }) => {
  const [bugs, setBugs] = useState(() => {
    const savedBugs = localStorage.getItem("bugs");
    return savedBugs ? JSON.parse(savedBugs) : [];
  });

  const [bugsId, setBugsId] = useState(() => {
    const savedIds = localStorage.getItem("bugsId");
    return savedIds ? JSON.parse(savedIds) : [];
  });

  
  useEffect(() => {
    localStorage.setItem("bugs", JSON.stringify(bugs));
  }, [bugs]);

  useEffect(() => {
    localStorage.setItem("bugsId", JSON.stringify(bugsId));
  }, [bugsId]);

  const addBug = (bug) => {
    setBugs((prev) => [...prev, bug]);
  };

  const deleteBug = (id) => {
    setBugs((prev) => prev.filter((bug) => bug.id !== id));
  };

  return (
    <BugContext.Provider
    value={{
      bugs,
      setBugs, 
      addBug,
      deleteBug,
      bugsId,
      setBugsId,
    }}
  >
    {children}
  </BugContext.Provider>
  
  );
};
