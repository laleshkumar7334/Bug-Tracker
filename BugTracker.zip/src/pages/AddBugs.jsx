import { toast } from 'react-toastify';

import React, { useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Box,
  Typography,
  TextField,
  Button,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  Paper,
} from "@mui/material";
import { useFormik } from "formik";
import * as yup from "yup";
import { v4 as uuidv4 } from "uuid";
import { BugContext } from "../contextApi/BugContext";


const bugSchema = yup.object({
  title: yup.string().required("Title is required").min(3, "Minimum 3 characters"),
  description: yup.string().required("Description is required").min(10, "Minimum 10 characters"),
  priority: yup.string().required("Priority is required"),
  status: yup.string().required("Status is required"),
  assignedTo: yup.string().required("Assigned To is required"),
});

const AddBug = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { bugs, setBugs, addBug, bugsId, setBugsId } = useContext(BugContext);

  const editingBug = bugs.find((bug) => bug.id === id);
 
  const formik = useFormik({
    initialValues: editingBug || {
      id: "",
      title: "",
      description: "",
      priority: "Low",
      status: "Open",
      assignedTo: "",
    },

    validationSchema: bugSchema,
    enableReinitialize: true, 

  
    onSubmit: async (values, { resetForm }) => {
      try {
        if (bugsId.length > 0) {
          const updatedBug = { ...values, id: id };
          const updatedBugs = bugs.map((bug) =>
            bug.id === updatedBug.id ? updatedBug : bug
          );
          setBugs(updatedBugs);
          setBugsId([]);
          toast.success("Bug updated successfully!");
        } else {
          const newBug = { ...values, id: uuidv4() };
          addBug(newBug);
          toast.success("Bug created successfully!");
        }
    
        resetForm();
        navigate("/");
      } catch (error) {
        console.error("Submission error:", error);
        toast.error("Something went wrong!");
      }
    }
    
  });

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h5" gutterBottom>
        {bugsId.length > 0 ? "Edit Bug" : "Create Bug"}
      </Typography>

      <Paper sx={{ p: 2 }}>
        <form onSubmit={formik.handleSubmit}>
          <Box display="flex" flexDirection="column" gap={2}>
            <TextField
              label="Title"
              name="title"
              fullWidth
              size="small"
              value={formik.values.title}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={formik.touched.title && Boolean(formik.errors.title)}
              helperText={formik.touched.title && formik.errors.title}
            />

            <TextField
              label="Description"
              name="description"
              fullWidth
              size="small"
              multiline
              rows={4}
              value={formik.values.description}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={formik.touched.description && Boolean(formik.errors.description)}
              helperText={formik.touched.description && formik.errors.description}
            />

            <FormControl fullWidth size="small">
              <InputLabel>Priority</InputLabel>
              <Select
                label="Priority"
                name="priority"
                value={formik.values.priority}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={formik.touched.priority && Boolean(formik.errors.priority)}
              >
                <MenuItem value="Low">Low</MenuItem>
                <MenuItem value="Medium">Medium</MenuItem>
                <MenuItem value="High">High</MenuItem>
              </Select>
            </FormControl>

            <FormControl fullWidth size="small">
              <InputLabel>Status</InputLabel>
              <Select
                label="Status"
                name="status"
                value={formik.values.status}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={formik.touched.status && Boolean(formik.errors.status)}
              >
                <MenuItem value="Open">Open</MenuItem>
                <MenuItem value="In Progress">In Progress</MenuItem>
                <MenuItem value="Closed">Closed</MenuItem>
              </Select>
            </FormControl>

            <TextField
              label="Assigned To"
              name="assignedTo"
              fullWidth
              size="small"
              value={formik.values.assignedTo}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={formik.touched.assignedTo && Boolean(formik.errors.assignedTo)}
              helperText={formik.touched.assignedTo && formik.errors.assignedTo}
            />

            <Box display="flex" gap={2} mt={2}>
              <Button
                variant="outlined"
                color="secondary"
                onClick={() => navigate("/")}
              >
                Cancel
              </Button>

              <Button variant="contained" type="submit">
                {editingBug ? "Update Bug" : "Create Bug"}
              </Button>
            </Box>
          </Box>
        </form>
      </Paper>
    </Box>
  );
};

export default AddBug;
