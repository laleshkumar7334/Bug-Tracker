import {
  Box,
  Typography,
  TextField,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  TableSortLabel,
  IconButton,
  Paper,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import { toast } from "react-toastify";

import { EditOutlined } from "@mui/icons-material";
import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";
import { useContext, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { BugContext } from "../contextApi/BugContext";

const BugsList = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const navigate = useNavigate();
  const { bugs, deleteBug,setBugs } = useContext(BugContext); 
  const {setBugsId}=useContext(BugContext);

  const [pageSize, setPageSize] = useState(10);
  const [page, setPage] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [order, setOrder] = useState("asc");
  const [orderBy, setOrderBy] = useState("title");
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [selectedBugId, setSelectedBugId] = useState(null);

  const columns = [
    { id: "title", label: "Title" },
    { id: "priority", label: "Priority" },
    { id: "status", label: "Status" },
    { id: "assignedTo", label: "Assigned To" },
  ];

  const filteredBugs = bugs.filter((bug) =>
    bug.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenDeleteDialog = (bugId) => {
    setSelectedBugId(bugId);
    setOpenDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => {
    setOpenDeleteDialog(false);
    setSelectedBugId(null);
  };

  const handleDeleteBug = (id) => {
    deleteBug(id);
    toast.success("Bug deleted successfully!"); 
    handleCloseDeleteDialog();
  };

  const handlePageChange = (event, newPage) => setPage(newPage);
  const handlePageSizeChange = (event) =>
    setPageSize(parseInt(event.target.value, 10));
  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const EditData = (id) => {
    setBugsId([id]);
    navigate(`/bug/${id}`); 
  };
  

  return (
    <Box
      sx={{
        height: "100%",
        width: "100%",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        bgcolor: "#f9f9f9",
        
      }}
    >
      <Box sx={{ mb: 2 }}>
        <Typography variant="h5" gutterBottom>
          Bug Tracker
        </Typography>
        <Paper sx={{ p: 2 }}>
          <Box
            display="flex"
            flexDirection={isMobile ? "column" : "row"}
            alignItems={isMobile ? "stretch" : "center"}
            justifyContent="space-between"
            gap={2}
          >
            <TextField
              label="Search Bugs"
              variant="outlined"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              size="small"
              sx={{
                width: isMobile ? "100%" : "300px",
                marginBottom: isMobile ? "16px" : "0",
              }}
            />
            <Button
              variant="contained"
              color="secondary"
              onClick={() => navigate("/bug/add")}
              sx={{ width: isMobile ? "100%" : "auto" }}
            >
              + Add New Bug
            </Button>
          </Box>
        </Paper>
      </Box>

      {/* Table Area */}
      <Box sx={{ flex: 1, overflow: "hidden" }}>
        <Paper
          sx={{
            height: "100%",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
            width: "100%",
          }}
        >
          {isMobile ? (
            <Box sx={{ p: 2 }}>
              {filteredBugs.length > 0 ? (
                filteredBugs
                  .slice(page * pageSize, page * pageSize + pageSize)
                  .map((bug) => (
                    <Paper key={bug.id} sx={{ mb: 2, p: 2 }}>
                      <Typography variant="h6">{bug.title}</Typography>
                      <Typography variant="body2">
                        Priority: {bug.priority}
                      </Typography>
                      <Typography variant="body2">
                        Status: {bug.status}
                      </Typography>
                      <Typography variant="body2">
                        Assigned To: {bug.assignedTo}
                      </Typography>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "flex-end",
                          gap: 1,
                          mt: 2,
                        }}
                      >
                        <IconButton
                          color="primary"
                        
                          onClick={() => EditData(bug.id)}
                        >
                          <EditOutlined />
                        </IconButton>
                        <IconButton
                          color="error"
                          onClick={() => handleOpenDeleteDialog(bug.id)}
                        >
                          <DeleteOutlinedIcon />
                        </IconButton>
                      </Box>
                    </Paper>
                  ))
              ) : (
                <Typography align="center">No bugs found.</Typography>
              )}
            </Box>
          ) : (
            <TableContainer sx={{ flex: 1, overflowY: "auto" }}>
              <Table stickyHeader>
                <TableHead>
                  <TableRow>
                    {columns.map((column) => (
                      <TableCell key={column.id}>
                        <TableSortLabel
                          active={orderBy === column.id}
                          direction={orderBy === column.id ? order : "asc"}
                          onClick={(e) => handleRequestSort(e, column.id)}
                        >
                          {column.label}
                        </TableSortLabel>
                      </TableCell>
                    ))}
                    <TableCell align="center">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredBugs.length > 0 ? (
                    filteredBugs
                      .slice(page * pageSize, page * pageSize + pageSize)
                      .map((bug) => (
                        <TableRow key={bug.id} hover>
                          <TableCell>{bug.title}</TableCell>
                          <TableCell>{bug.priority}</TableCell>
                          <TableCell>{bug.status}</TableCell>
                          <TableCell>{bug.assignedTo}</TableCell>
                          <TableCell align="center">
                            <IconButton
                              color="primary"
                              
                               onClick={() => EditData(bug.id)}

                            >
                              <EditOutlined />
                            </IconButton>
                            <IconButton
                              color="error"
                              onClick={() => handleOpenDeleteDialog(bug.id)}
                            >
                              <DeleteOutlinedIcon />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={5} align="center">
                        No bugs found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          )}

          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={filteredBugs.length}
            rowsPerPage={pageSize}
            page={page}
            onPageChange={handlePageChange}
            onRowsPerPageChange={handlePageSizeChange}
          />
        </Paper>
      </Box>

      {/* Delete Dialog */}
      <Dialog open={openDeleteDialog} onClose={handleCloseDeleteDialog}>
        <DialogTitle>Confirm Deletion</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to delete this bug?</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDeleteDialog}>Cancel</Button>
          <Button
            color="error"
            variant="contained"
            onClick={() => handleDeleteBug(selectedBugId)}
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default BugsList;
