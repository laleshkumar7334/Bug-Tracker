import './App.css';
import AddBugs from './pages/AddBugs';
import BugsList from './pages/BugsList';
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ToastContainer } from 'react-toastify';
function App() {
  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />
    <Router>
      <Routes>
        {/* Root Route with the BugsList Component */}
        <Route path="/" element={<BugsList />} />
        <Route path='/bug/add' element={<AddBugs/>}/>
        <Route path='/bug/:id' element={<AddBugs />} />

      </Routes>
    </Router>
    </>
  );
}

export default App;
